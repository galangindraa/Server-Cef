Water Level Flood on LS Canal
------------------------------------------------------------------------------------------------
Mod Water Level Flood sur LS Canal pour GTA San Andreas The Definitive Edition. C’est l’un des paramètres du mod Water Level Mod, qui remplit le canal de Los Santos d’eau. Le canal est non seulement rempli d’eau, mais vous pouvez également y observer des vagues.

Vous pouvez télécharger le mod Water Level Flood sur LS Canal pour GTA San Andreas Definitive Edition avec installation automatique ou manuellement vers les liens ci-dessous sur cette page.

MOD ne remplace pas les fichiers de jeu d’origine.
Chemin d’installation : [dossier du jeu]\Gameface\Content\Paks\mods\

################################################################################################

AUTEURS
------------------------------------------------------------------------------------------------
L'auteur principal ctxrlsec

################################################################################################

INSTRUCTIONS D'INSTALLATION
------------------------------------------------------------------------------------------------
1. La copie des fichiers

(!) Ne pas oublier de faire des copies de l'original remplacés fichiers pour être en mesure de retirer la modification!

Copiez tout le contenu du dossier "00 - Copy to game folder" dans le dossier où le jeu est installé. Confirmer le remplacement.

################################################################################################

Cette modification a été téléchargé à partir de www.gtaall.eu

Permanent lien vers modification`s page: https://www.gtaall.eu/fr/gta-san-andreas-definitive-edition/mods/169219-water-level-flood-on-ls-canal.html

Vérifier notre sociale groups!
http://vk.com/gtaallcom
https://twitter.com/gtaallcom
http://www.facebook.com/gtaallcom
http://www.youtube.com/gtaallcom