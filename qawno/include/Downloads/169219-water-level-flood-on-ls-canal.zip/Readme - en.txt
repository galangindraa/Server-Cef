Water Level Flood on LS Canal
------------------------------------------------------------------------------------------------
Mod Water Level Flood on LS Canal for GTA San Andreas The Definitive Edition. This is one of the settings of the mod Water Level Mod, which fills the canal in Los Santos with water. The canal is not only filled with water, but you can also observe waves in it.

You can download mod Water Level Flood on LS Canal for GTA San Andreas Definitive Edition with automatic installation or manually to the links below on this page.

MOD does not replace the original game files.
Installation path: [game folder]\Gameface\Content\Paks\mods\

################################################################################################

AUTHORS
------------------------------------------------------------------------------------------------
Main author ctxrlsec

################################################################################################

INSTALLATION INSTRUCTIONS
------------------------------------------------------------------------------------------------
1. File copying

(!) Do not forget to make copies of the original replaced files to be able to remove the modification!

Copy all the contents of the folder "00 - Copy to game folder" to the folder where the game is installed. Confirm the replacement.

################################################################################################

This modification has been downloaded from www.gtaall.com

Permanent link to modification`s page: https://www.gtaall.com/gta-san-andreas-definitive-edition/mods/169219-water-level-flood-on-ls-canal.html

Check out our social groups!
http://vk.com/gtaallcom
https://twitter.com/gtaallcom
http://www.facebook.com/gtaallcom
http://www.youtube.com/gtaallcom