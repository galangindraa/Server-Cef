Water Level Flood on LS Canal
------------------------------------------------------------------------------------------------
Mod Water Level Flood en LS Canal para GTA San Andreas The Definitive Edition. Esta es una de las configuraciones del mod Water Level Mod, que llena de agua el canal de Los Santos. El canal no solo está lleno de agua, sino que también se pueden observar olas en él.

Puede descargar mod Water Level Flood en LS Canal para GTA San Andreas Definitive Edition con instalación automática o manualmente a los enlaces a continuación en esta página.

MOD no reemplaza los archivos de juego originales.
Ruta de instalación: [carpeta del juego]\Gameface\Content\Paks\mods\

################################################################################################

AUTORES
------------------------------------------------------------------------------------------------
Autor principal ctxrlsec

################################################################################################

INSTRUCCIONES DE INSTALACIÓN
------------------------------------------------------------------------------------------------
1. La copia de archivos

(!) No se olvide de hacer copias de la original de los archivos reemplazados a ser capaz de eliminar la modificación!

Copie todo el contenido de la carpeta "00 - Copy to game folder" a la carpeta donde está instalado el juego. Confirmar el reemplazo.

################################################################################################

Esta modificación ha sido descargado de www.gtaall.net

Permanent enlace a modification`s página: https://www.gtaall.net/gta-san-andreas-definitive-edition/mods/169219-water-level-flood-on-ls-canal.html

Compruebe nuestra sociales groups!
http://vk.com/gtaallcom
https://twitter.com/gtaallnet
http://www.facebook.com/gtaallcom
http://www.youtube.com/gtaallcom