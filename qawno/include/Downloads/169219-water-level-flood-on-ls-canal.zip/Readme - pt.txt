Water Level Flood on LS Canal
------------------------------------------------------------------------------------------------
Mod Water Level Flood no Canal LS para GTA San Andreas The Definitive Edition. Esta é uma das configurações do mod Water Level Mod, que enche o canal em Los Santos com água. O canal não está apenas cheio de água, mas também pode observar ondas nele.

Você pode baixar mod Water Level Flood no Canal LS para GTA San Andreas Definitive Edition com instalação automática ou manualmente para os links abaixo nesta página.

MOD não substitui os arquivos originais do jogo.
Caminho de instalação: [pasta do jogo]\Gameface\Content\Paks\mods\

################################################################################################

AUTORES
------------------------------------------------------------------------------------------------
Autor principal ctxrlsec

################################################################################################

INSTRUÇÕES DE INSTALAÇÃO
------------------------------------------------------------------------------------------------
1. Cópia de arquivo

(!) Não se esqueça de fazer cópias do original arquivos substituídos para ser capaz de remover a modificação!

Copie todo o conteúdo da pasta "00 - Copy to game folder" para a pasta onde o jogo está instalado. Confirmar a substituição.

################################################################################################

Esta modificação foi baixado www.gtaall.com.br

Permanent link para modification`s página: https://www.gtaall.com.br/gta-san-andreas-definitive-edition/mods/169219-water-level-flood-on-ls-canal.html

Check a nossa sociais groups!
http://vk.com/gtaallcom
https://twitter.com/gtaallcombr
http://www.facebook.com/gtaallcom
http://www.youtube.com/gtaallcom