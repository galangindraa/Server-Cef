Cacher le HUD
------------------------------------------------------------------------------------------------
Longtemps espéré de retirer son film, film, série télé, etc., mais interféré avec HUD ?
Ce MOD vous aidera à résoudre le problème
en appuyant sur le "B" (en anglais) et cacher le HUD de l'écran.

################################################################################################

AUTEURS
------------------------------------------------------------------------------------------------
Wmysterio

################################################################################################

INSTRUCTIONS D'INSTALLATION
------------------------------------------------------------------------------------------------
1. La copie des fichiers

(!) Ne pas oublier de faire des copies de l'original remplacés fichiers pour être en mesure de retirer la modification!

Copiez tout le contenu du dossier "00 - Copy to game folder" dans le dossier où le jeu est installé. Confirmer le remplacement.

################################################################################################

Cette modification a été téléchargé à partir de www.gtaall.eu

Permanent lien vers modification`s page: https://www.gtaall.eu/fr/gta-san-andreas/cleo/32130-hide-hud.html

Vérifier notre sociale groups!
http://vk.com/gtaallcom
https://twitter.com/gtaallcom
http://www.facebook.com/gtaallcom
http://www.youtube.com/gtaallcom