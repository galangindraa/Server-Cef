Ocultar HUD
------------------------------------------------------------------------------------------------
¿Larga espera a retirar su película, película, serie de TV, etc., pero interfiere con HUD?
Este MOD te ayudará a resolver el problema
por la "B" (Inglés) se presiona y ocultar el HUD de la pantalla.

################################################################################################

AUTORES
------------------------------------------------------------------------------------------------
Wmysterio

################################################################################################

INSTRUCCIONES DE INSTALACIÓN
------------------------------------------------------------------------------------------------
1. La copia de archivos

(!) No se olvide de hacer copias de la original de los archivos reemplazados a ser capaz de eliminar la modificación!

Copie todo el contenido de la carpeta "00 - Copy to game folder" a la carpeta donde está instalado el juego. Confirmar el reemplazo.

################################################################################################

Esta modificación ha sido descargado de www.gtaall.net

Permanent enlace a modification`s página: https://www.gtaall.net/gta-san-andreas/cleo/32130-hide-hud.html

Compruebe nuestra sociales groups!
http://vk.com/gtaallcom
https://twitter.com/gtaallnet
http://www.facebook.com/gtaallcom
http://www.youtube.com/gtaallcom