Hide HUD
------------------------------------------------------------------------------------------------
Long hoped to withdraw his film, movie, TV series, etc., but interfered with HUD?
This MOD will help you solve the problem
by pressing the "B" (English) and hide the HUD from the screen.

################################################################################################

AUTHORS
------------------------------------------------------------------------------------------------
Wmysterio

################################################################################################

INSTALLATION INSTRUCTIONS
------------------------------------------------------------------------------------------------
1. File copying

(!) Do not forget to make copies of the original replaced files to be able to remove the modification!

Copy all the contents of the folder "00 - Copy to game folder" to the folder where the game is installed. Confirm the replacement.

################################################################################################

This modification has been downloaded from www.gtaall.com

Permanent link to modification`s page: https://www.gtaall.com/gta-san-andreas/cleo/32130-hide-hud.html

Check out our social groups!
http://vk.com/gtaallcom
https://twitter.com/gtaallcom
http://www.facebook.com/gtaallcom
http://www.youtube.com/gtaallcom