Esconder HUD
------------------------------------------------------------------------------------------------
Longa espera-se a retirar seu filme, série de TV, filme, etc, mas interferiu no HUD?
Este MOD irá ajudá-lo a resolver o problema
por pressionar o "B" (inglês) e esconder o HUD da tela.

################################################################################################

AUTORES
------------------------------------------------------------------------------------------------
Wmysterio

################################################################################################

INSTRUÇÕES DE INSTALAÇÃO
------------------------------------------------------------------------------------------------
1. Cópia de arquivo

(!) Não se esqueça de fazer cópias do original arquivos substituídos para ser capaz de remover a modificação!

Copie todo o conteúdo da pasta "00 - Copy to game folder" para a pasta onde o jogo está instalado. Confirmar a substituição.

################################################################################################

Esta modificação foi baixado www.gtaall.com.br

Permanent link para modification`s página: https://www.gtaall.com.br/gta-san-andreas/cleo/32130-hide-hud.html

Check a nossa sociais groups!
http://vk.com/gtaallcom
https://twitter.com/gtaallcombr
http://www.facebook.com/gtaallcom
http://www.youtube.com/gtaallcom