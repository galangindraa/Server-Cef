HUD ausblenden
------------------------------------------------------------------------------------------------
Mischte lange hoffte, seinen Film zurückzuziehen, Film, TV-Serien usw., sondern sich mit HUD?
Diese MOD hilft Ihnen das Problem zu lösen
durch Drücken das "B" (Deutsch) und verstecken das HUD vom Bildschirm.

################################################################################################

AUTOREN
------------------------------------------------------------------------------------------------
Wmysterio

################################################################################################

EINBAUANLEITUNG
------------------------------------------------------------------------------------------------
1. Kopieren von Dateien

(!) Vergessen Sie nicht, machen Kopien des Originals ersetzt Dateien in der Lage sein, um die Änderung zu entfernen!

Kopieren Sie den gesamten Inhalt des Ordners "00 - Copy to game folder" auf den Ordner, in dem das Spiel installiert ist. Bestätigen Sie den Ersatz.

################################################################################################

Diese Modifikation wurde von www.gtaall.eu heruntergeladen wurden
Permanent Link zu Seite modification`s: https://www.gtaall.eu/de/gta-san-andreas/cleo/32130-hide-hud.html

Überprüfen unsere sozialen groups!
http://vk.com/gtaallcom
https://twitter.com/gtaallcom
http://www.facebook.com/gtaallcom
http://www.youtube.com/gtaallcom